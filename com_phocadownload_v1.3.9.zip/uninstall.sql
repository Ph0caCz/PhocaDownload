DROP TABLE IF EXISTS `#__phocadownload`;
DROP TABLE IF EXISTS `#__phocadownload_categories`;
DROP TABLE IF EXISTS `#__phocadownload_sections`;
DROP TABLE IF EXISTS `#__phocadownload_settings`;
DROP TABLE IF EXISTS `#__phocadownload_user_stat`;
DROP TABLE IF EXISTS `#__phocadownload_licenses`;
