ALTER TABLE `#__phocadownload` ADD COLUMN `project_name` varchar(255) NOT NULL default '';
ALTER TABLE `#__phocadownload_categories` ADD COLUMN `project_name` varchar(255) NOT NULL default '';
